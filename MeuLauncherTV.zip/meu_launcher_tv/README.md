# Meu Launcher TV — protótipo HTML

Este projeto é uma interface visual de launcher para TV, feita em HTML, CSS e JavaScript puro. O estilo foi refinado para reduzir brilhos e gradientes exagerados, com foco mais discreto e acabamento mais sóbrio.

## Como testar
1. Abra `index.html` no navegador.
2. Use o controle remoto/teclas de setas para navegar entre elementos focáveis; clique também funciona no navegador.
3. Abra a engrenagem no topo para personalizar a cor de destaque. A cor é aplicada aos botões selecionados, contornos e destaques, sem alterar o fundo.
4. A cor escolhida fica salva localmente no navegador por `localStorage`.

## Importante sobre APK e Android TV
Este arquivo é um protótipo web. Para virar um APK que funcione como launcher real no Android TV 11, ele precisa ser empacotado em um app Android (por exemplo, WebView dentro de um projeto Android) e configurado com uma Activity que declare a categoria `HOME`/`DEFAULT`. Abrir aplicativos instalados, listar pacotes e tornar-se tela inicial padrão exigem integração nativa Android e permissões/compatibilidade do fabricante. O HTML sozinho não substitui o launcher do sistema.

## Conteúdo visual
Os cartões e banners usam arte abstrata gerada por CSS e títulos demonstrativos. O protótipo não reproduz filmes, não transmite vídeos e não abre os aplicativos reais automaticamente.
